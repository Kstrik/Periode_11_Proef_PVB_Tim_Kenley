﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace FoodFast
{
	public partial class App : Application
    {
        public NavigationPage NavigationPage { get; private set; }

        public App ()
		{
			//InitializeComponent();

            var menuPage = new MenuPage();
            NavigationPage = new NavigationPage(new Dashboard());
            var rootPage = new RootPage();
            rootPage.Master = menuPage;
            rootPage.Detail = NavigationPage;
            MainPage = rootPage;

            //MainPage = new FoodFast.MainPage();
            //MainPage = new FoodFast.Dashboard();
        }

        protected override void OnStart ()
		{
			// Handle when your app starts
		}

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}
	}
}
