﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace FoodFast
{
    class DatabaseHandler
    {
        WebClient webClient;

        public DatabaseHandler()
        {
            webClient = new WebClient();
        }

        public string ExecuteQuery(string Query, string RequestType)
        {
            string response = "";
            string url = "http://b8f57f4a.ngrok.io/api/contact/";

            switch (RequestType)
            {
                case "GET":
                    {
                        //string response = webClient.DownloadString("http://localhost:52983/api/data/" + Query);
                        response = webClient.DownloadString(url);
                        break;
                    }
                case "POST":
                    {
                        //string myParameters = "testpost";

                        ////var reqparm = new System.Collections.Specialized.NameValueCollection();
                        ////reqparm.Add("param1", "test");
                        //response = webClient.UploadString(url, myParameters);
                        ////webClient.UploadValues(" http://07c8438f.ngrok.io/api/contact/", "POST", reqparm);

                        WebClient wc = new WebClient();
                        wc.QueryString.Add("parameter1", "TestPost");
                        var data = wc.UploadValues(url, "POST", wc.QueryString);

                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return response;
        }
    }
}
