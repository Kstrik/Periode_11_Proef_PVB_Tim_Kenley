﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FoodFast
{
    class ControlsGenerator
    {
        public ControlsGenerator()
        {

        }

        public TableView tableViewFromData(List<string[]> data, EventHandler eventHandler)
        {
            TableRoot tableRoot = new TableRoot();
            TableSection tableSection = new TableSection();

            for (int i = 0; i < data.Count; i++)
            {
                ImageCell imageCell = new ImageCell();
                //imageCell.ImageSource = Device.OnPlatform(ImageSource.FromUri(new Uri("http://xamarin.com/images/index/ide-xamarin-studio.png")), ImageSource.FromFile("ide_xamarin_studio.png"), ImageSource.FromFile("Images/ide-xamarin-studio.png"));
                imageCell.ImageSource = Device.OnPlatform(ImageSource.FromUri(new Uri("http://xamarin.com/images/index/ide-xamarin-studio.png")), ImageSource.FromFile("Icon.png"), ImageSource.FromFile("Recources/Drawable/Icon.png"));
                imageCell.Text = data[i][1];
                imageCell.TextColor = Color.Black;
                //imageCell.Detail = data[i][2];
                imageCell.Tapped += eventHandler;

                tableSection.Add(imageCell);

                //TextCell textCell = new TextCell();
                //textCell.Text = data[i][1];
                //textCell.Detail = data[i][2];

                //tableSection.Add(textCell);
            }
            tableRoot.Add(tableSection);

            TableView tableView = new TableView();
            tableView.Intent = TableIntent.Form;
            tableView.Root = tableRoot;

            return tableView;
        }
    }
}
