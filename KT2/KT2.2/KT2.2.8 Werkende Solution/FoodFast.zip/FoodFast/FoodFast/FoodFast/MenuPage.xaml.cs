﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FoodFast
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MenuPage : ContentPage
	{
		public MenuPage ()
		{
            Title = "Menu";
            InitializeComponent ();
		}

        private void TextCell_Tabbed(object sender, EventArgs e)
        {
            TextCell textCell = (TextCell)sender;

            switch(textCell.Text)
            {
                case "Dashboard":
                    {
                        RootPage rootPage = (RootPage)this.Parent;

                        rootPage.Detail = new NavigationPage(new Dashboard());
                        break;
                    }
                case "Favorite":
                    {
                        RootPage rootPage = (RootPage)this.Parent;

                        rootPage.Detail = new NavigationPage(new Favorites());
                        break;
                    }
                case "Recent":
                    {
                        RootPage rootPage = (RootPage)this.Parent;

                        rootPage.Detail = new NavigationPage(new Recents());
                        break;
                    }
                case "Help":
                    {
                        RootPage rootPage = (RootPage)this.Parent;

                        rootPage.Detail = new NavigationPage(new Help());
                        break;
                    }
            }
        }

    }
}