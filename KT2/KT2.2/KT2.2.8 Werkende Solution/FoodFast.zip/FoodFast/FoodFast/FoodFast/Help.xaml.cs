﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FoodFast
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Help : ContentPage
	{
		public Help ()
		{
			InitializeComponent ();
		}

        private void TextCell_Tabbed(object sender, EventArgs e)
        {
            TextCell textCell = (TextCell)sender;

            switch (textCell.Text)
            {
                case "Vraag inzenden":
                    {
                        RootPage rootPage = (RootPage)this.Parent;

                        //rootPage.Detail = new NavigationPage(new Dashboard());
                        break;
                    }
                case "FAQ":
                    {
                        RootPage rootPage = (RootPage)this.Parent;

                        //rootPage.Detail = new NavigationPage(new Favorites());
                        break;
                    }
            }
        }
    }
}