﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FoodFast
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Recents : ContentPage
	{
		public Recents ()
		{
			InitializeComponent ();

            List<string[]> list = new List<string[]> { };
            for (int i = 0; i < 10; i++)
            {
                string[] details = new string[3];
                details[0] = "1";
                details[1] = "McDonalds";
                details[2] = "Is een keten";
                list.Add(details);
            }
            ControlsGenerator controlsGenerator = new ControlsGenerator();

            stk_Content.Children.Add(controlsGenerator.tableViewFromData(list, btn_Cell_Tapped));
        }

        private async void btn_Cell_Tapped(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Recent());
        }
    }
}