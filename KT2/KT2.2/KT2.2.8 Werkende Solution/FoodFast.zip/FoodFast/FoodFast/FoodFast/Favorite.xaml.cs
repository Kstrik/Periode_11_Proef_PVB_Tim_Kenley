﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FoodFast
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Favorite : ContentPage
	{
		public Favorite ()
		{
			InitializeComponent ();

            //img_Image.Source = Device.OnPlatform(ImageSource.FromUri(new Uri("http://xamarin.com/images/index/ide-xamarin-studio.png")), ImageSource.FromFile("Icon.png"), ImageSource.FromFile("Recources/Drawable/Icon.png"));
        }
    }
}